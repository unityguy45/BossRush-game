# Tode: Boss Rush

A 3D browser boss rush starring Tode the Frog, built with [Three.js](https://threejs.org/) and [Vite](https://vite.dev/). Fight four titans in a floating lava arena using nothing but your tongue.

![Title screen](media/title.jpg)


[Watch the 20-second gameplay video](media/gameplay.mp4)

## How to play

| Input | Action |
| --- | --- |
| `W` `A` `S` `D` | Move |
| Mouse | Aim |
| Click / `J` | Tongue: lash enemies, grab rubble, grapple pillars |
| Click while holding rubble | Throw it (hits much harder than a lash) |
| `Space` | Jump over shockwaves |
| `Shift` | Dash (invincible while dashing) |
| `P` | Pause |

Eight stone pillars ring the arena. You can grapple onto them to zip across the arena, and they crack and collapse every few seconds, leaving rubble you can throw at the bosses. Pillars grow back over time.

## The bosses

1. **Kilnheart, the Magma Colossus**: flying fists, meteor showers, ground-pounding leaps. No shield, but its slams smash pillars into rubble.
2. **Oculus, the Storm Eye**: sweeping lasers, spiral bullet storms, lightning. Shielded until you destroy its glowing wards.
3. **Regina Apis, the Hive Queen**: charges, stinger fans, honey bombs and swarms. Shielded by royal guards you have to beat first.
4. **Nidhogg, the Void Serpent**: dives under the arena and bursts up beneath you. Its void shield only breaks to thrown rubble.

Every boss enters a rage phase at half health.

![Kilnheart fight](media/screenshot-golem.jpg)
![Oculus fight](media/screenshot-eye.jpg)

## Run it

```bash
npm install
npm run dev
```

Then open the link Vite prints. `npm run build` makes a production build in `dist/`.

## Tuning

- Boss health, colors and attack patterns: `src/components/Bosses.js`
- Player, tongue, rubble and pillar numbers: `src/components/Constants.js`

## Credits

Started from the JetBrains Academy course *Build a Game with an AI Coding Agent* (MIT license, see `LICENSE`), which provides the Tode, enemy and house models.
